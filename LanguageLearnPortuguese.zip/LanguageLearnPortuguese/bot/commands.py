import discord
from discord import app_commands
from discord.ext import commands
from bot.embeds import create_config_embed, create_help_embed
from bot.views import EvaluationView

def setup_commands(bot, bot_config, evaluation_system):
    """Configura todos os comandos do bot"""
    
    @bot.command(name="avaliar", help="Iniciar uma avaliação da loja")
    async def avaliar(ctx):
        """Comando principal para iniciar avaliação"""
        
        # Verificar se o canal de avaliações está configurado
        eval_channel_id = bot_config.get_evaluation_channel(ctx.guild.id)
        if not eval_channel_id:
            embed = discord.Embed(
                title="⚠️ Canal não configurado",
                description="O canal de avaliações não foi configurado ainda.\n"
                           "Um administrador precisa usar `!config canal` primeiro.",
                color=0xFFCC00
            )
            await ctx.send(embed=embed)
            return
        
        # Criar a view de avaliação
        view = EvaluationView(evaluation_system, ctx.author, ctx)
        
        # Embed inicial
        embed = discord.Embed(
            title="⭐ Sistema de Avaliação da Loja",
            description="Olá! Obrigado por escolher nossa loja.\n"
                       "Sua opinião é muito importante para nós!\n\n"
                       "**Clique no botão abaixo para começar sua avaliação:**",
            color=0x00D4AA
        )
        embed.add_field(
            name="📋 O que vamos avaliar:",
            value="• 🛍️ **Atendimento** - Como foi o atendimento?\n"
                  "• 📦 **Produto** - Qualidade do produto recebido\n"
                  "• 🚚 **Entrega** - Rapidez e cuidado na entrega",
            inline=False
        )
        embed.set_footer(text="💡 Processo rápido e fácil - sem formulários!")
        
        message = await ctx.send(embed=embed, view=view)
        view.message = message
    
    @bot.command(name="config", help="Configurações do sistema de avaliação")
    async def config(ctx, acao=None, *, argumento=None):
        """Comando de configuração (apenas admins)"""
        
        if not bot_config.is_admin(ctx.author):
            embed = discord.Embed(
                title="❌ Acesso negado",
                description="Apenas administradores podem usar este comando.",
                color=0xFF4444
            )
            await ctx.send(embed=embed)
            return
        
        if not acao:
            embed = discord.Embed(
                title="📋 Comandos de Configuração",
                description="Use: `!config <comando> [argumento]`",
                color=0x5865F2
            )
            embed.add_field(
                name="Comandos disponíveis:",
                value="`!config canal #canal` - Define canal de avaliações\n"
                      "`!config add_role @role` - Adiciona role admin\n"
                      "`!config remove_role @role` - Remove role admin\n"
                      "`!config status` - Ver configurações\n"
                      "`!config help` - Esta ajuda",
                inline=False
            )
            await ctx.send(embed=embed)
            return
        
        if acao == "canal":
            if not ctx.message.channel_mentions:
                embed = discord.Embed(
                    title="❌ Canal não especificado",
                    description="Você precisa mencionar um canal.\n"
                               "Exemplo: `!config canal #avaliações`",
                    color=0xFF4444
                )
                await ctx.send(embed=embed)
                return
            
            canal = ctx.message.channel_mentions[0]
            bot_config.set_evaluation_channel(ctx.guild.id, canal.id)
            embed = discord.Embed(
                title="✅ Canal configurado!",
                description=f"Canal de avaliações definido como {canal.mention}",
                color=0x00D4AA
            )
            await ctx.send(embed=embed)
        
        elif acao == "add_role":
            if not ctx.message.role_mentions:
                embed = discord.Embed(
                    title="❌ Role não especificada",
                    description="Você precisa mencionar uma role.\n"
                               "Exemplo: `!config add_role @Moderador`",
                    color=0xFF4444
                )
                await ctx.send(embed=embed)
                return
            
            role = ctx.message.role_mentions[0]
            bot_config.add_admin_role(ctx.guild.id, role.id)
            embed = discord.Embed(
                title="✅ Role adicionada!",
                description=f"Role {role.mention} agora pode gerenciar o sistema de avaliações",
                color=0x00D4AA
            )
            await ctx.send(embed=embed)
        
        elif acao == "remove_role":
            if not ctx.message.role_mentions:
                embed = discord.Embed(
                    title="❌ Role não especificada",
                    description="Você precisa mencionar uma role para remover.",
                    color=0xFF4444
                )
                await ctx.send(embed=embed)
                return
            
            role = ctx.message.role_mentions[0]
            bot_config.remove_admin_role(ctx.guild.id, role.id)
            embed = discord.Embed(
                title="✅ Role removida!",
                description=f"Role {role.mention} não pode mais gerenciar o sistema",
                color=0x00D4AA
            )
            await ctx.send(embed=embed)
        
        elif acao == "status":
            embed = create_config_embed(bot_config, ctx.guild)
            await ctx.send(embed=embed)
        
        elif acao == "help":
            embed = create_help_embed()
            await ctx.send(embed=embed)
    
    @bot.command(name="ajuda", help="Mostra informações sobre como usar o bot")
    async def ajuda(ctx):
        """Comando de ajuda para usuários"""
        embed = create_help_embed(admin=False)
        await ctx.send(embed=embed)
    
    @bot.command(name="stats", help="Estatísticas das avaliações (apenas admins)")
    async def stats(ctx):
        """Mostra estatísticas das avaliações"""
        
        if not bot_config.is_admin(ctx.author):
            embed = discord.Embed(
                title="❌ Acesso negado",
                description="Apenas administradores podem ver as estatísticas.",
                color=0xFF4444
            )
            await ctx.send(embed=embed)
            return
        
        stats_data = evaluation_system.get_stats(ctx.guild.id)
        
        embed = discord.Embed(
            title="📊 Estatísticas das Avaliações",
            color=0x5865F2
        )
        
        embed.add_field(
            name="📈 Resumo Geral",
            value=f"**Total de avaliações:** {stats_data['total']}\n"
                  f"**Média geral:** {'⭐' * int(stats_data['average_general'])} ({stats_data['average_general']:.1f}/5)",
            inline=False
        )
        
        if stats_data['total'] > 0:
            embed.add_field(
                name="🛍️ Atendimento",
                value=f"Média: {'⭐' * int(stats_data['average_service'])} ({stats_data['average_service']:.1f}/5)",
                inline=True
            )
            
            embed.add_field(
                name="📦 Produto",
                value=f"Média: {'⭐' * int(stats_data['average_product'])} ({stats_data['average_product']:.1f}/5)",
                inline=True
            )
            
            embed.add_field(
                name="🚚 Entrega",
                value=f"Média: {'⭐' * int(stats_data['average_delivery'])} ({stats_data['average_delivery']:.1f}/5)",
                inline=True
            )
        
        embed.set_footer(text="💡 Dados atualizados em tempo real")
        
        await ctx.send(embed=embed)
