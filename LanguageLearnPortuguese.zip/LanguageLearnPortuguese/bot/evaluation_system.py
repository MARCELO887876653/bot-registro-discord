import json
import os
from datetime import datetime
from typing import Dict, List, Optional

class EvaluationSystem:
    """Sistema de gerenciamento de avaliações"""
    
    def __init__(self, config):
        self.config = config
        self.evaluations_file = "data/evaluations.json"
        self.evaluations = self.load_evaluations()
    
    def load_evaluations(self) -> Dict:
        """Carrega avaliações do arquivo JSON"""
        try:
            if os.path.exists(self.evaluations_file):
                with open(self.evaluations_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception as e:
            print(f"❌ Erro ao carregar avaliações: {e}")
        
        return {"guilds": {}}
    
    def save_evaluations(self):
        """Salva avaliações no arquivo JSON"""
        try:
            os.makedirs(os.path.dirname(self.evaluations_file), exist_ok=True)
            with open(self.evaluations_file, 'w', encoding='utf-8') as f:
                json.dump(self.evaluations, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"❌ Erro ao salvar avaliações: {e}")
    
    def add_evaluation(self, guild_id: int, user_id: int, user_name: str, ratings: Dict, comment: str = None):
        """Adiciona uma nova avaliação"""
        guild_str = str(guild_id)
        
        if guild_str not in self.evaluations["guilds"]:
            self.evaluations["guilds"][guild_str] = []
        
        evaluation = {
            "user_id": user_id,
            "user_name": user_name,
            "timestamp": datetime.now().isoformat(),
            "ratings": ratings,
            "comment": comment,
            "id": len(self.evaluations["guilds"][guild_str]) + 1
        }
        
        self.evaluations["guilds"][guild_str].append(evaluation)
        self.save_evaluations()
        
        return evaluation
    
    def get_evaluations(self, guild_id: int) -> List[Dict]:
        """Retorna todas as avaliações de um servidor"""
        guild_str = str(guild_id)
        return self.evaluations["guilds"].get(guild_str, [])
    
    def get_stats(self, guild_id: int) -> Dict:
        """Calcula estatísticas das avaliações"""
        evaluations = self.get_evaluations(guild_id)
        
        if not evaluations:
            return {
                "total": 0,
                "average_general": 0.0,
                "average_service": 0.0,
                "average_product": 0.0,
                "average_delivery": 0.0
            }
        
        total = len(evaluations)
        
        # Calcular médias
        service_sum = sum(eval_data["ratings"]["service"] for eval_data in evaluations)
        product_sum = sum(eval_data["ratings"]["product"] for eval_data in evaluations)
        delivery_sum = sum(eval_data["ratings"]["delivery"] for eval_data in evaluations)
        
        avg_service = service_sum / total
        avg_product = product_sum / total
        avg_delivery = delivery_sum / total
        avg_general = (avg_service + avg_product + avg_delivery) / 3
        
        return {
            "total": total,
            "average_general": round(avg_general, 1),
            "average_service": round(avg_service, 1),
            "average_product": round(avg_product, 1),
            "average_delivery": round(avg_delivery, 1)
        }
    
    def get_recent_evaluations(self, guild_id: int, limit: int = 5) -> List[Dict]:
        """Retorna as avaliações mais recentes"""
        evaluations = self.get_evaluations(guild_id)
        return sorted(evaluations, key=lambda x: x["timestamp"], reverse=True)[:limit]
    
    def stars_to_emoji(self, rating: int) -> str:
        """Converte número para emojis de estrelas"""
        full_stars = "⭐" * rating
        empty_stars = "☆" * (5 - rating)
        return full_stars + empty_stars
    
    def rating_to_text(self, rating: int) -> str:
        """Converte rating para texto descritivo"""
        texts = {
            1: "Muito ruim",
            2: "Ruim", 
            3: "Regular",
            4: "Bom",
            5: "Excelente"
        }
        return texts.get(rating, "Não avaliado")
