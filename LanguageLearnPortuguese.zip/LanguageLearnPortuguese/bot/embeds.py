import discord
from datetime import datetime

def create_config_embed(config, guild):
    """Cria embed com configurações atuais"""
    
    eval_channel_id = config.get_evaluation_channel(guild.id)
    eval_channel = guild.get_channel(eval_channel_id) if eval_channel_id else None
    
    embed = discord.Embed(
        title="⚙️ Configurações do Sistema",
        color=0x5865F2
    )
    
    # Canal de avaliações
    channel_text = eval_channel.mention if eval_channel else "❌ Não configurado"
    embed.add_field(
        name="📍 Canal de Avaliações",
        value=channel_text,
        inline=True
    )
    
    # Roles administrativas
    guild_str = str(guild.id)
    admin_roles = []
    if guild_str in config.config["guilds"]:
        admin_role_ids = config.config["guilds"][guild_str]["admin_roles"]
        for role_id in admin_role_ids:
            role = guild.get_role(role_id)
            if role:
                admin_roles.append(role.mention)
    
    roles_text = "\n".join(admin_roles) if admin_roles else "❌ Nenhuma configurada"
    embed.add_field(
        name="👥 Roles Administrativas",
        value=roles_text,
        inline=True
    )
    
    # Status geral
    status = "✅ Ativo" if eval_channel else "⚠️ Necessita configuração"
    embed.add_field(
        name="📊 Status",
        value=status,
        inline=True
    )
    
    # Configurações adicionais
    if guild_str in config.config["guilds"]:
        settings = config.config["guilds"][guild_str]["settings"]
        
        settings_text = ""
        if settings.get("require_confirmation", True):
            settings_text += "✅ Confirmação obrigatória\n"
        if settings.get("allow_anonymous", False):
            settings_text += "👤 Avaliações anônimas permitidas\n"
        if settings.get("auto_delete_commands", True):
            settings_text += "🗑️ Auto-exclusão de comandos\n"
        
        if settings_text:
            embed.add_field(
                name="🔧 Configurações Extras",
                value=settings_text,
                inline=False
            )
    
    embed.set_footer(text="💡 Use /config para modificar as configurações")
    
    return embed

def create_help_embed(admin=True):
    """Cria embed de ajuda"""
    
    embed = discord.Embed(
        title="❓ Ajuda - Sistema de Avaliações",
        description="Sistema interativo para coleta de avaliações da loja",
        color=0x00D4AA
    )
    
    # Comandos para usuários
    embed.add_field(
        name="👥 Comandos para Clientes",
        value="`!avaliar` - Iniciar uma nova avaliação\n"
              "`!ajuda` - Mostrar esta mensagem de ajuda",
        inline=False
    )
    
    if admin:
        # Comandos administrativos
        embed.add_field(
            name="⚙️ Comandos Administrativos",
            value="`!config canal #canal` - Definir canal de avaliações\n"
                  "`!config add_role @role` - Adicionar role administrativa\n"
                  "`!config remove_role @role` - Remover role administrativa\n"
                  "`!config status` - Ver configurações atuais\n"
                  "`!stats` - Ver estatísticas das avaliações",
            inline=False
        )
        
        # Guia de configuração inicial
        embed.add_field(
            name="🚀 Configuração Inicial",
            value="1️⃣ Use `!config canal #canal` para definir onde as avaliações aparecerão\n"
                  "2️⃣ Opcional: Use `!config add_role @role` para adicionar moderadores\n"
                  "3️⃣ Pronto! Os usuários já podem usar `!avaliar`",
            inline=False
        )
    
    # Sobre o sistema
    embed.add_field(
        name="💡 Como Funciona",
        value="• Sistema totalmente interativo com botões e reações\n"
              "• Avaliação de 3 aspectos: Atendimento, Produto e Entrega\n"
              "• Processo rápido sem formulários complicados\n"
              "• Avaliações enviadas automaticamente para o canal configurado",
        inline=False
    )
    
    embed.set_footer(text="🤖 Bot de Avaliações - Versão 1.0")
    
    return embed

def create_evaluation_embed(evaluation_data, user_name):
    """Cria embed para exibir uma avaliação completa"""
    
    embed = discord.Embed(
        title="⭐ Nova Avaliação Recebida!",
        color=0x00D4AA,
        timestamp=datetime.fromisoformat(evaluation_data["timestamp"])
    )
    
    # Informações do avaliador
    embed.set_author(
        name=f"Avaliação de {user_name}",
        icon_url="https://cdn.discordapp.com/emojis/896109790956499005.png"
    )
    
    ratings = evaluation_data["ratings"]
    
    # Mostrar avaliações com emojis
    embed.add_field(
        name="🛍️ Atendimento",
        value=f"{'⭐' * ratings['service']}{'☆' * (5-ratings['service'])} ({ratings['service']}/5)",
        inline=True
    )
    
    embed.add_field(
        name="📦 Produto", 
        value=f"{'⭐' * ratings['product']}{'☆' * (5-ratings['product'])} ({ratings['product']}/5)",
        inline=True
    )
    
    embed.add_field(
        name="🚚 Entrega",
        value=f"{'⭐' * ratings['delivery']}{'☆' * (5-ratings['delivery'])} ({ratings['delivery']}/5)",
        inline=True
    )
    
    # Média geral
    average = (ratings['service'] + ratings['product'] + ratings['delivery']) / 3
    embed.add_field(
        name="📊 Média Geral",
        value=f"{'⭐' * int(round(average))}{'☆' * (5-int(round(average)))} ({average:.1f}/5)",
        inline=False
    )
    
    # Comentário se houver
    if evaluation_data.get("comment"):
        embed.add_field(
            name="💬 Comentário",
            value=f"*\"{evaluation_data['comment']}\"*",
            inline=False
        )
    
    embed.set_footer(text=f"ID da Avaliação: #{evaluation_data['id']}")
    
    return embed

def create_rating_embed(category, category_emoji, description):
    """Cria embed para avaliação de categoria específica"""
    
    embed = discord.Embed(
        title=f"{category_emoji} Avaliação - {category}",
        description=f"{description}\n\n**Clique nas estrelas abaixo para avaliar:**",
        color=0x5865F2
    )
    
    embed.add_field(
        name="⭐ Escala de Avaliação",
        value="⭐ = Muito ruim\n"
              "⭐⭐ = Ruim\n"
              "⭐⭐⭐ = Regular\n"
              "⭐⭐⭐⭐ = Bom\n"
              "⭐⭐⭐⭐⭐ = Excelente",
        inline=False
    )
    
    return embed

def create_comment_embed():
    """Cria embed para coleta de comentário opcional"""
    
    embed = discord.Embed(
        title="💬 Comentário Adicional",
        description="Gostaria de deixar um comentário sobre sua experiência?\n\n"
                   "**Você pode:**\n"
                   "• Escrever um comentário\n"
                   "• Pular esta etapa",
        color=0x9966CC
    )
    
    embed.add_field(
        name="✍️ Como comentar",
        value="Digite sua mensagem na conversa ou clique em 'Pular' para continuar sem comentário.",
        inline=False
    )
    
    return embed

def create_confirmation_embed(ratings, comment=None):
    """Cria embed de confirmação final"""
    
    embed = discord.Embed(
        title="✅ Confirmar Avaliação",
        description="Por favor, confirme sua avaliação antes de enviar:",
        color=0xFFCC00
    )
    
    # Mostrar todas as avaliações
    embed.add_field(
        name="🛍️ Atendimento",
        value=f"{'⭐' * ratings['service']}{'☆' * (5-ratings['service'])} ({ratings['service']}/5)",
        inline=True
    )
    
    embed.add_field(
        name="📦 Produto",
        value=f"{'⭐' * ratings['product']}{'☆' * (5-ratings['product'])} ({ratings['product']}/5)",
        inline=True
    )
    
    embed.add_field(
        name="🚚 Entrega",
        value=f"{'⭐' * ratings['delivery']}{'☆' * (5-ratings['delivery'])} ({ratings['delivery']}/5)",
        inline=True
    )
    
    # Comentário se houver
    if comment:
        embed.add_field(
            name="💬 Seu comentário",
            value=f"*\"{comment}\"*",
            inline=False
        )
    
    embed.set_footer(text="💡 Clique em 'Confirmar' para enviar sua avaliação")
    
    return embed
