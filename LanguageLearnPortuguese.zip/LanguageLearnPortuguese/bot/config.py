import json
import os
from typing import Dict, Optional

class BotConfig:
    """Gerenciador de configurações do bot"""
    
    def __init__(self):
        self.config_file = "data/config.json"
        self.config = self.load_config()
    
    def load_config(self) -> Dict:
        """Carrega configurações do arquivo JSON"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception as e:
            print(f"❌ Erro ao carregar configurações: {e}")
        
        # Configuração padrão
        return {
            "guilds": {}
        }
    
    def save_config(self):
        """Salva configurações no arquivo JSON"""
        try:
            os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"❌ Erro ao salvar configurações: {e}")
    
    def setup_guild(self, guild_id: int):
        """Configura um servidor se não existir"""
        guild_str = str(guild_id)
        if guild_str not in self.config["guilds"]:
            self.config["guilds"][guild_str] = {
                "evaluation_channel": None,
                "admin_roles": [],
                "settings": {
                    "require_confirmation": True,
                    "allow_anonymous": False,
                    "auto_delete_commands": True
                }
            }
            self.save_config()
    
    def set_evaluation_channel(self, guild_id: int, channel_id: int):
        """Define o canal de avaliações"""
        guild_str = str(guild_id)
        self.setup_guild(guild_id)
        self.config["guilds"][guild_str]["evaluation_channel"] = channel_id
        self.save_config()
    
    def get_evaluation_channel(self, guild_id: int) -> Optional[int]:
        """Retorna o canal de avaliações configurado"""
        guild_str = str(guild_id)
        if guild_str in self.config["guilds"]:
            return self.config["guilds"][guild_str].get("evaluation_channel")
        return None
    
    def add_admin_role(self, guild_id: int, role_id: int):
        """Adiciona uma role de administrador"""
        guild_str = str(guild_id)
        self.setup_guild(guild_id)
        if role_id not in self.config["guilds"][guild_str]["admin_roles"]:
            self.config["guilds"][guild_str]["admin_roles"].append(role_id)
            self.save_config()
    
    def remove_admin_role(self, guild_id: int, role_id: int):
        """Remove uma role de administrador"""
        guild_str = str(guild_id)
        if guild_str in self.config["guilds"]:
            admin_roles = self.config["guilds"][guild_str]["admin_roles"]
            if role_id in admin_roles:
                admin_roles.remove(role_id)
                self.save_config()
    
    def is_admin(self, member) -> bool:
        """Verifica se o membro é administrador"""
        if member.guild_permissions.administrator:
            return True
        
        guild_str = str(member.guild.id)
        if guild_str in self.config["guilds"]:
            admin_roles = self.config["guilds"][guild_str]["admin_roles"]
            return any(role.id in admin_roles for role in member.roles)
        
        return False
    
    def get_setting(self, guild_id: int, setting: str, default=None):
        """Retorna uma configuração específica"""
        guild_str = str(guild_id)
        if guild_str in self.config["guilds"]:
            return self.config["guilds"][guild_str]["settings"].get(setting, default)
        return default
    
    def set_setting(self, guild_id: int, setting: str, value):
        """Define uma configuração específica"""
        guild_str = str(guild_id)
        self.setup_guild(guild_id)
        self.config["guilds"][guild_str]["settings"][setting] = value
        self.save_config()
