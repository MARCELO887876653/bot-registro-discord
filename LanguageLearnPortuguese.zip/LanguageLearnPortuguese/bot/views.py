import discord
from discord.ext import commands
import asyncio
from bot.embeds import (
    create_rating_embed, 
    create_comment_embed, 
    create_confirmation_embed,
    create_evaluation_embed
)

class RatingView(discord.ui.View):
    """View para coleta de avaliação por estrelas"""
    
    def __init__(self, category, category_emoji, description, evaluation_view, step_id=0):
        super().__init__(timeout=300)
        self.category = category
        self.category_emoji = category_emoji
        self.description = description
        self.evaluation_view = evaluation_view
        self.rating = None
        self.step_id = step_id
    
    @discord.ui.button(label="⭐", style=discord.ButtonStyle.secondary)
    async def rating_1(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._handle_rating(interaction, 1)
    
    @discord.ui.button(label="⭐⭐", style=discord.ButtonStyle.secondary)
    async def rating_2(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._handle_rating(interaction, 2)
    
    @discord.ui.button(label="⭐⭐⭐", style=discord.ButtonStyle.secondary)
    async def rating_3(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._handle_rating(interaction, 3)
    
    @discord.ui.button(label="⭐⭐⭐⭐", style=discord.ButtonStyle.primary)
    async def rating_4(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._handle_rating(interaction, 4)
    
    @discord.ui.button(label="⭐⭐⭐⭐⭐", style=discord.ButtonStyle.success)
    async def rating_5(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._handle_rating(interaction, 5)
    
    async def _handle_rating(self, interaction: discord.Interaction, rating: int):
        """Processa a seleção de rating"""
        self.rating = rating
        
        # Feedback visual
        embed = discord.Embed(
            title=f"✅ {self.category} avaliado!",
            description=f"Você deu {'⭐' * rating} para {self.category.lower()}",
            color=0x00D4AA
        )
        
        # Usar defer para não bloquear a interaction
        await interaction.response.defer()
        await interaction.edit_original_response(embed=embed, view=None)
        
        # Processar o rating na evaluation view
        await self.evaluation_view.process_rating(interaction, rating)
        self.stop()
    
    async def on_timeout(self):
        """Callback quando o tempo limite é atingido"""
        self.clear_items()

class CommentView(discord.ui.View):
    """View para coleta de comentário opcional"""
    
    def __init__(self, evaluation_view):
        super().__init__(timeout=300)
        self.evaluation_view = evaluation_view
        self.comment = None
    
    @discord.ui.button(label="✍️ Deixar comentário", style=discord.ButtonStyle.primary)
    async def add_comment(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Inicia processo de comentário"""
        
        # Modal para comentário
        modal = CommentModal(self.evaluation_view)
        await interaction.response.send_modal(modal)
        self.stop()
    
    @discord.ui.button(label="⏭️ Pular", style=discord.ButtonStyle.secondary)
    async def skip_comment(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Pula o comentário"""
        
        embed = discord.Embed(
            title="⏭️ Comentário pulado",
            description="Prosseguindo para confirmação...",
            color=0x99AAB5
        )
        
        await interaction.response.defer()
        await interaction.edit_original_response(embed=embed, view=None)
        
        # Processar comentário vazio
        await self.evaluation_view.process_comment(interaction, None)
        self.stop()

class CommentModal(discord.ui.Modal):
    """Modal para entrada de comentário"""
    
    def __init__(self, evaluation_view):
        super().__init__(title="💬 Deixe seu comentário")
        self.evaluation_view = evaluation_view
    
    comment_input = discord.ui.TextInput(
        label="Conte-nos sobre sua experiência:",
        placeholder="Digite aqui seu comentário sobre a compra...",
        style=discord.TextStyle.paragraph,
        max_length=500,
        required=True
    )
    
    async def on_submit(self, interaction: discord.Interaction):
        """Processa o comentário enviado"""
        
        embed = discord.Embed(
            title="✅ Comentário adicionado!",
            description="Obrigado pelo seu feedback adicional!",
            color=0x00D4AA
        )
        
        # Para modals, usamos response.edit_message
        await interaction.response.edit_message(embed=embed, view=None)
        
        # Processar comentário
        await self.evaluation_view.process_comment(interaction, self.comment_input.value)

class ConfirmationView(discord.ui.View):
    """View para confirmação final da avaliação"""
    
    def __init__(self, evaluation_view):
        super().__init__(timeout=300)
        self.evaluation_view = evaluation_view
    
    @discord.ui.button(label="✅ Confirmar e Enviar", style=discord.ButtonStyle.success)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Confirma e envia a avaliação"""
        
        embed = discord.Embed(
            title="🚀 Enviando avaliação...",
            description="Processando sua avaliação...",
            color=0x5865F2
        )
        
        await interaction.response.defer()
        await interaction.edit_original_response(embed=embed, view=None)
        
        # Submeter a avaliação
        await self.evaluation_view.submit_evaluation(interaction)
        self.stop()
    
    @discord.ui.button(label="❌ Cancelar", style=discord.ButtonStyle.danger)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Cancela a avaliação"""
        
        embed = discord.Embed(
            title="❌ Avaliação cancelada",
            description="Sua avaliação foi cancelada. Você pode iniciar uma nova a qualquer momento com `!avaliar`.",
            color=0xFF4444
        )
        
        await interaction.response.defer()
        await interaction.edit_original_response(embed=embed, view=None)
        self.stop()

class EvaluationView(discord.ui.View):
    """View principal que gerencia todo o processo de avaliação"""
    
    def __init__(self, evaluation_system, user, ctx=None):
        super().__init__(timeout=600)
        self.evaluation_system = evaluation_system
        self.user = user
        self.ctx = ctx
        self.message = None
        self.ratings = {}
        self.comment = None
        self.current_step = 0
        self.current_interaction = None
        
        # Passos da avaliação
        self.steps = [
            ("Atendimento", "🛍️", "Como foi o atendimento que você recebeu?", "service"),
            ("Produto", "📦", "Qual a qualidade do produto que você recebeu?", "product"),
            ("Entrega", "🚚", "Como foi a rapidez e cuidado na entrega?", "delivery")
        ]
    
    @discord.ui.button(label="🚀 Começar Avaliação", style=discord.ButtonStyle.primary)
    async def start_evaluation(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Inicia o processo de avaliação"""
        self.current_interaction = interaction
        await interaction.response.defer()
        await self.next_rating_step()
    
    async def next_rating_step(self):
        """Próximo passo de avaliação"""
        if self.current_step < len(self.steps):
            category, emoji, description, key = self.steps[self.current_step]
            
            embed = create_rating_embed(category, emoji, description)
            view = RatingView(category, emoji, description, self, self.current_step)
            
            if self.current_interaction:
                await self.current_interaction.edit_original_response(embed=embed, view=view)
            elif self.message:
                await self.message.edit(embed=embed, view=view)
        else:
            await self.collect_comment()
    
    async def process_rating(self, interaction, rating):
        """Processa uma avaliação recebida"""
        category, emoji, description, key = self.steps[self.current_step]
        self.ratings[key] = rating
        self.current_step += 1
        self.current_interaction = interaction
        
        # Aguardar um pouco antes do próximo passo
        await asyncio.sleep(1.5)
        
        # Continuar para próxima avaliação ou comentário
        await self.next_rating_step()
    
    async def collect_comment(self):
        """Coleta comentário opcional"""
        embed = create_comment_embed()
        view = CommentView(self)
        
        if self.current_interaction:
            await self.current_interaction.edit_original_response(embed=embed, view=view)
        elif self.message:
            await self.message.edit(embed=embed, view=view)
    
    async def process_comment(self, interaction, comment):
        """Processa o comentário recebido"""
        self.comment = comment
        self.current_interaction = interaction
        await asyncio.sleep(1)
        await self.show_confirmation()
    
    async def show_confirmation(self):
        """Mostra confirmação final"""
        embed = create_confirmation_embed(self.ratings, self.comment)
        view = ConfirmationView(self)
        
        if self.current_interaction:
            await self.current_interaction.edit_original_response(embed=embed, view=view)
        elif self.message:
            await self.message.edit(embed=embed, view=view)
    
    async def submit_evaluation(self, interaction):
        """Submete a avaliação final"""
        try:
            # Adicionar avaliação ao sistema
            evaluation_data = self.evaluation_system.add_evaluation(
                guild_id=self.user.guild.id,
                user_id=self.user.id,
                user_name=self.user.display_name,
                ratings=self.ratings,
                comment=self.comment
            )
            
            # Enviar para canal de avaliações
            eval_channel_id = self.evaluation_system.config.get_evaluation_channel(self.user.guild.id)
            if eval_channel_id:
                channel = self.user.guild.get_channel(eval_channel_id)
                if channel:
                    embed = create_evaluation_embed(evaluation_data, self.user.display_name)
                    await channel.send(embed=embed)
            
            # Confirmação final para o usuário
            final_embed = discord.Embed(
                title="🎉 Avaliação enviada com sucesso!",
                description="Obrigado por avaliar nossa loja! Sua opinião é muito importante para nós.",
                color=0x00D4AA
            )
            final_embed.add_field(
                name="📊 Sua avaliação:",
                value=f"🛍️ Atendimento: {'⭐' * self.ratings['service']}\n"
                      f"📦 Produto: {'⭐' * self.ratings['product']}\n"
                      f"🚚 Entrega: {'⭐' * self.ratings['delivery']}",
                inline=False
            )
            
            if self.comment:
                final_embed.add_field(
                    name="💬 Seu comentário:",
                    value=f"*\"{self.comment}\"*",
                    inline=False
                )
            
            final_embed.set_footer(text="✨ Esperamos você em breve para novas compras!")
            
            await interaction.edit_original_response(embed=final_embed, view=None)
            
        except Exception as e:
            # Embed de erro
            final_embed = discord.Embed(
                title="❌ Erro ao enviar avaliação",
                description="Ocorreu um erro ao processar sua avaliação. Tente novamente mais tarde.",
                color=0xFF4444
            )
            print(f"Erro ao submeter avaliação: {e}")
            
            await interaction.edit_original_response(embed=final_embed, view=None)