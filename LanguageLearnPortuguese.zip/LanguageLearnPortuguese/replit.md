# Discord Store Evaluation Bot

## Overview

This is a Discord bot designed to collect and manage customer evaluations for a store. The bot provides an interactive evaluation system where users can rate different aspects of their shopping experience (customer service, product quality, and delivery) using a star-based rating system with optional comments.

## System Architecture

### Backend Architecture
- **Language**: Python 3.x
- **Framework**: discord.py (Discord API wrapper)
- **Command System**: Hybrid approach using both traditional commands and Discord slash commands
- **Data Storage**: JSON-based file storage for configurations and evaluations
- **Async Architecture**: Built on asyncio for handling Discord events and user interactions

### Data Storage Solutions
- **Configuration Data**: Stored in `data/config.json` - contains guild-specific settings, evaluation channels, and admin roles
- **Evaluation Data**: Stored in `data/evaluations.json` - contains all user evaluations with ratings, comments, and metadata
- **File Structure**: Simple JSON structure with guild-based organization for multi-server support

### Authentication and Authorization
- **Discord Integration**: Uses Discord's OAuth2 system through bot tokens
- **Role-Based Access**: Admin commands restricted to users with configured administrative roles
- **Guild Isolation**: Each Discord server (guild) has independent configuration and data

## Key Components

### 1. Bot Core (`main.py`)
- Discord bot initialization with required intents (message content, reactions)
- Event handlers for bot readiness and guild joining
- Slash command synchronization
- Integration point for all bot modules

### 2. Configuration System (`bot/config.py`)
- `BotConfig` class manages guild-specific settings
- Handles evaluation channel configuration
- Manages administrative roles per guild
- Provides methods for setting/getting configuration values

### 3. Evaluation System (`bot/evaluation_system.py`)
- `EvaluationSystem` class handles all evaluation data operations
- Stores evaluations with user information, ratings, and timestamps
- Provides methods for adding evaluations and calculating statistics
- Maintains evaluation history per guild

### 4. Command System (`bot/commands.py`)
- Implements slash commands for evaluation initiation and configuration
- `/avaliar` - Main command for users to start evaluations
- `/config` - Administrative command for bot configuration
- Integration with Discord's application command system

### 5. Interactive UI (`bot/views.py`)
- `RatingView` - Interactive button-based rating system (1-5 stars)
- `EvaluationView` - Main workflow coordinator for the evaluation process
- Handles user interactions, timeouts, and state management
- Provides visual feedback throughout the evaluation process

### 6. Message Formatting (`bot/embeds.py`)
- Standardized Discord embed creation for consistent UI
- Evaluation forms, confirmation messages, and status displays
- Configuration overview embeds for administrators

## Data Flow

1. **User Initiates Evaluation**: User runs `/avaliar` command
2. **System Validation**: Bot checks if evaluation channel is configured
3. **Interactive Collection**: User rates three categories (service, product, delivery) using star buttons
4. **Optional Comment**: User can provide additional written feedback
5. **Confirmation**: User reviews and confirms their evaluation
6. **Storage**: Evaluation is saved to JSON with user metadata and timestamp
7. **Channel Posting**: Final evaluation is posted to the configured evaluation channel

## External Dependencies

### Required Python Packages
- `discord.py` - Discord API wrapper for bot functionality
- `asyncio` - Asynchronous I/O support (built-in)
- `json` - JSON data handling (built-in)
- `os` - Operating system interface (built-in)

### Discord Requirements
- Discord Bot Token (via DISCORD_TOKEN environment variable)
- Bot permissions: Send Messages, Use Slash Commands, Embed Links, Add Reactions
- Guild-specific channel configuration for evaluation posting

## Deployment Strategy

### Environment Setup
- Requires `DISCORD_TOKEN` environment variable
- Creates `data/` directory structure automatically
- No external database dependencies - uses local JSON files

### File Structure
```
/
├── main.py                 # Bot entry point
├── bot/
│   ├── config.py          # Configuration management
│   ├── commands.py        # Slash command definitions
│   ├── evaluation_system.py # Evaluation data handling
│   ├── views.py           # Interactive UI components
│   └── embeds.py          # Message formatting
└── data/
    ├── config.json        # Guild configurations
    └── evaluations.json   # Evaluation data
```

### Scalability Considerations
- JSON storage suitable for small to medium deployments
- Easy migration path to database systems (SQLite, PostgreSQL) if needed
- Guild-based data isolation supports multiple Discord servers

## Changelog

- July 08, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.