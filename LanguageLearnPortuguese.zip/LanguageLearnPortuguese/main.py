import discord
from discord.ext import commands
import os
import json
import asyncio
from bot.config import BotConfig
from bot.commands import setup_commands
from bot.evaluation_system import EvaluationSystem

# Configuração dos intents
intents = discord.Intents.default()
intents.message_content = True
intents.reactions = True

# Inicialização do bot
bot = commands.Bot(command_prefix='!', intents=intents, help_command=None)

# Sistema de configuração e avaliação
bot_config = BotConfig()
evaluation_system = EvaluationSystem(bot_config)

@bot.event
async def on_ready():
    """Evento disparado quando o bot está pronto"""
    print(f'🤖 {bot.user} está online!')
    print(f'📊 Sistema de Avaliações carregado')
    
    # Comandos tradicionais carregados automaticamente
    print(f'✅ {len(bot.commands)} comandos carregados')

@bot.event
async def on_guild_join(guild):
    """Evento disparado quando o bot entra em um servidor"""
    bot_config.setup_guild(guild.id)
    print(f'📥 Bot adicionado ao servidor: {guild.name}')

# Configurar comandos
setup_commands(bot, bot_config, evaluation_system)

# Executar o bot
if __name__ == "__main__":
    token = os.getenv("DISCORD_TOKEN", "SEU_TOKEN_AQUI")
    if token == "SEU_TOKEN_AQUI":
        print("❌ ERRO: Token do Discord não configurado!")
        print("📝 Configure a variável de ambiente DISCORD_TOKEN")
    else:
        bot.run(token)
